import pyaudio
import wave
import os
import sys
import boto3
import time
import urllib
import json
from datetime import datetime
from s3_crud import upload_file

def get_recording_device_info():
    p = pyaudio.PyAudio()
    index_audio_device = 0
    for ii in range(p.get_device_count()):
        audio_device = p.get_device_info_by_index(ii)
        maxInputChannels = audio_device.get('maxInputChannels')
        if maxInputChannels == 0:
            continue
        return audio_device
    return None

def record_voice(recording_config):
    wav_output_filename = recording_config["file_location"]
    device_info = recording_config["device_info"]
    form_1 = pyaudio.paInt16 # 16-bit resolution
    chans = device_info["maxInputChannels"] # 1 channel
    samp_rate = int(device_info["defaultSampleRate"]) # 44.1kHz sampling rate
    chunk = 4096 # 2^12 samples for buffer
    record_secs = recording_config["record_seconds"] # seconds to record
    dev_index = device_info["index"] # device index found by p.get_device_info_by_index(ii)

    audio = pyaudio.PyAudio() # create pyaudio instantiation

    # create pyaudio stream
    stream = audio.open(format = form_1,rate = samp_rate,channels = chans, \
                        input_device_index = dev_index,input = True, \
                        frames_per_buffer=chunk)
    print("recording")
    frames = []

    # loop through stream and append audio chunks to frame array
    for ii in range(0,int((samp_rate/chunk)*record_secs)):
        data = stream.read(chunk)
        frames.append(data)

    print("finished recording")

    # stop the stream, close it, and terminate the pyaudio instantiation
    stream.stop_stream()
    stream.close()
    audio.terminate()

    # save the audio frames as .wav file
    wavefile = wave.open(wav_output_filename,'wb')
    wavefile.setnchannels(chans)
    wavefile.setsampwidth(audio.get_sample_size(form_1))
    wavefile.setframerate(samp_rate)
    wavefile.writeframes(b''.join(frames))
    wavefile.close()

def save_to_s3(local_file_location, s3_bucket_name, s3_file_location=None):
    # upload file at s3 location
    if s3_file_location is None:
        s3_file_location = os.path.basename(local_file_location)
    file_uri = "s3://" + s3_bucket_name + "/" + s3_file_location
    file_uploaded = upload_file(local_file_location, s3_bucket_name, s3_file_location)
    if not file_uploaded:
        print("error uploading file")
        return False, file_uri
    print("File uploaded successfully")
    return True, file_uri

transcribe_client = boto3.client('transcribe')

def get_transcribe_client():
    global transcribe_client
    return transcribe_client

def transcribe_file(job_name, file_uri, transcribe_client):
    transcribe_client.start_transcription_job(
        TranscriptionJobName=job_name,
        Media={'MediaFileUri': file_uri},
        MediaFormat='wav',
        LanguageCode='en-US'
    )

    max_tries = 60
    output_text = ''
    while max_tries > 0:
        max_tries -= 1
        job = transcribe_client.get_transcription_job(TranscriptionJobName=job_name)
        job_status = job['TranscriptionJob']['TranscriptionJobStatus']
        if job_status in ['COMPLETED', 'FAILED']:
            print(f"Job {job_name} is {job_status}.")
            if job_status == 'COMPLETED':
                response = urllib.request.urlopen(job['TranscriptionJob']['Transcript']['TranscriptFileUri'])
                data = json.loads(response.read())
                print(data)
                output_text = data['results']['transcripts'][0]['transcript']
                print("========== below is output of speech-to-text ========================")
                print(output_text)
                print("=====================================================================")
            break
        else:
            print(f"Waiting for {job_name}. Current status is {job_status}.")
        time.sleep(10)
    return output_text

def transcribe_speech(s3_uri):
    now = datetime.now()
    current_time = now.strftime("%H-%M-%S")
    name = "speech_job_transcribe"

    output_text = transcribe_file(f"{name}{current_time}", s3_uri, get_transcribe_client())

def clean_aws_resources():
    # delete s3 file
    # delete s3 bucket
    pass

if __name__ == "__main__":
    config = {
        "recording_config": {
            "file_location" : "/tmp/test_audio.wav",
            "record_seconds" : 5,
            "device_info": None
        },
        "s3_config": {
            "bucket_name": "myfacedemo",
            "s3_file_location": None, # specify s3 location else local filename will be used
        }
    }
    device_info = get_recording_device_info()
    if device_info == None:
        print("Input device not found")
        exit(1)
    config["recording_config"]["device_info"] = device_info
    
    recording_config = config["recording_config"]
    record_voice(recording_config)
    
    s3_config = config["s3_config"]
    status, s3_uri = save_to_s3(recording_config["file_location"], s3_config["bucket_name"], s3_file_location=None)
    if not status:
        print("failed saving at s3", s3_uri)
    
    transcribe_speech(s3_uri)

    clean_aws_resources()

    
