import boto3
from boto3 import Session
from botocore.exceptions import BotoCoreError, ClientError
from contextlib import closing
import os
import sys
import subprocess
from tempfile import gettempdir
import pygame
import RPi.GPIO as GPIO
import time
import urllib
import json
from picamera import PiCamera
import pyaudio
import wave
from s3_crud import list_bucket, upload_file, file_exists_s3, delete_file
from aws_speech_to_text import transcribe_file, get_transcribe_client
import sys
from datetime import datetime
from time import sleep

GPIO.setmode(GPIO.BCM)
 
GPIO_TRIGGER = 18
GPIO_ECHO = 12
buzzer=23
 
GPIO.setup(GPIO_TRIGGER, GPIO.OUT)
GPIO.setup(GPIO_ECHO, GPIO.IN)
GPIO.setup(buzzer,GPIO.OUT)

def askpolly():
    polly = boto3.client('polly')
    try:
        response = polly.synthesize_speech(Text="Hi, What is your name?", OutputFormat="mp3", VoiceId="Joanna")
    except (BotoCoreError, ClientError) as error:
        print(error)
        sys.exit(-1)
    if "AudioStream" in response:
            with closing(response["AudioStream"]) as stream:
                output = os.path.join(gettempdir(), "speech.mp3")
                print("audio saved at", output)
                try:
                # Open a file for writing the output as a binary stream
                    with open(output, "wb") as file:
                        file.write(stream.read())
                except IOError as error:
                # Could not write to file, exit gracefully
                    print(error)
                    sys.exit(-1)
    else:
        # The response didn't contain audio data, exit gracefully
        print("Could not stream audio")
        sys.exit(-1)

    pygame.mixer.init()
    pygame.mixer.music.load("/tmp/speech.mp3")
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy() == True:
        continue
    

def clickpic():
    directory = '/opt/code/aws_text_2_speech' #folder name on your raspberry pi
    P=PiCamera()
    P.resolution= (800,600)
    P.start_preview()
    collectionId='mycollection' #collection name
    rek_client=boto3.client('rekognition')
    time.sleep(2)       
    milli = int(round(time.time() * 1000))
    image = '{}/image_{}.jpg'.format(directory,milli)
    P.capture(image) #capture an image
    print('captured '+image)
    with open(image, 'rb') as image:
        try: 
            match_response = rek_client.search_faces_by_image(CollectionId=collectionId, Image={'Bytes': image.read()}, MaxFaces=1, FaceMatchThreshold=85)
            if match_response['FaceMatches']:
                print('Hello, ',match_response['FaceMatches'][0]['Face']['ExternalImageId'])
                print('Similarity: ',match_response['FaceMatches'][0]['Similarity'])
                print('Confidence: ',match_response['FaceMatches'][0]['Face']['Confidence'])  
                BlowBuzzer()
            else:
                print('No faces matched')
        except:
            print('No face detected')     

def recordaudio():
    p = pyaudio.PyAudio()
    index_audio_device = 0
    for ii in range(p.get_device_count()):
        audio_device = p.get_device_info_by_index(ii)
        print(index_audio_device, ii, audio_device.get('name'))
        print("maxInputChannels", audio_device.get('maxInputChannels'))
        print("maxOutputChannels", audio_device.get('maxOutputChannels'))
        print(audio_device)
        index_audio_device = index_audio_device + 1

    form_1 = pyaudio.paInt16 # 16-bit resolution
    chans = 1 # 1 channel
    samp_rate = 48000 # 44.1kHz sampling rate
    chunk = 4096 # 2^12 samples for buffer
    record_secs = 10 # seconds to record
    dev_index = 2 # device index found by p.get_device_info_by_index(ii)
    wav_output_filename = 'test1.wav' # name of .wav file
    audio = pyaudio.PyAudio() # create pyaudio instantiation

    stream = audio.open(format = form_1,rate = samp_rate,channels = chans, \
                        input_device_index = dev_index,input = True, \
                        frames_per_buffer=chunk)
    print("recording")
    frames = []

    for ii in range(0,int((samp_rate/chunk)*record_secs)):
        data = stream.read(chunk)
        frames.append(data)

    print("finished recording")

    stream.stop_stream()
    stream.close()
    audio.terminate()

    wavefile = wave.open(wav_output_filename,'wb')
    wavefile.setnchannels(chans)
    wavefile.setsampwidth(audio.get_sample_size(form_1))
    wavefile.setframerate(samp_rate)
    wavefile.writeframes(b''.join(frames))
    wavefile.close()  
    

def speechtotext():
    s3_bucket_name = 'myfacedemo'
    s3_buckets, err = list_bucket()
    if err is not None:
        print("error while bucket listing", err)
        sys.exit(-1)
    print("buckets", s3_buckets)
    s3_bucket_exists = False
    for bucket in s3_buckets:
        if bucket['Name'] == s3_bucket_name:
            s3_bucket_exists = True
            break

    if file_exists_s3(s3_bucket_name, "test1.wav"):
        print("file exists")
    else:
        print("file not exists")
        speech_mp3_file_location = "/opt/code/aws_text_2_speech/test1.wav"
        file_uploaded = upload_file(speech_mp3_file_location, s3_bucket_name)
        if not file_uploaded:
            print("error uploading file")
            sys.exit(-1)
        print("File uploaded successfully")

    file_uri = "s3://" + s3_bucket_name + "/test1.wav"
    now = datetime.now()
    current_time = now.strftime("%H-%M-%S")
    name = "speech_job_transcribe"
    print("Current Time =", current_time)
    output_text = transcribe_file(f"{name}{current_time}", file_uri, get_transcribe_client())
    print("transcribed text :", output_text)
    delete_file(s3_bucket_name, "test1.wav")
    

def BlowBuzzer() : 
    GPIO.output(buzzer,GPIO.HIGH)
    sleep(0.5) 
    GPIO.output(buzzer,GPIO.LOW)
    sleep(0.5)

 
def distance():
    GPIO.output(GPIO_TRIGGER, True)
    time.sleep(0.00001)
    GPIO.output(GPIO_TRIGGER, False)
    StartTime = time.time()
    StopTime = time.time()
    while GPIO.input(GPIO_ECHO) == 0:
        StartTime = time.time()
    while GPIO.input(GPIO_ECHO) == 1:
        StopTime = time.time()
    TimeElapsed = StopTime - StartTime
    distance = (TimeElapsed * 34300) / 2
    return distance

if __name__ == '__main__':
    while True:
        dist = distance()
        print ("Measured Distance = %.1f cm" % dist)
        if dist < 10:
            # print ("call polly")
            askpolly()
            recordaudio()
            speechtotext()
            clickpic()
            # break
    #     # time.sleep(1)